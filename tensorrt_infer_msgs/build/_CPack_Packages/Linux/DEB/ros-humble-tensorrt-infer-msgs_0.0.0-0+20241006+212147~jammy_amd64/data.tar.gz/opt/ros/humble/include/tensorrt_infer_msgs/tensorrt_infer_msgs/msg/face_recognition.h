// generated from rosidl_generator_c/resource/idl.h.em
// with input from tensorrt_infer_msgs:msg/FaceRecognition.idl
// generated code does not contain a copyright notice

#ifndef TENSORRT_INFER_MSGS__MSG__FACE_RECOGNITION_H_
#define TENSORRT_INFER_MSGS__MSG__FACE_RECOGNITION_H_

#include "tensorrt_infer_msgs/msg/detail/face_recognition__struct.h"
#include "tensorrt_infer_msgs/msg/detail/face_recognition__functions.h"
#include "tensorrt_infer_msgs/msg/detail/face_recognition__type_support.h"

#endif  // TENSORRT_INFER_MSGS__MSG__FACE_RECOGNITION_H_
