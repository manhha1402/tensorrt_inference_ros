from tensorrt_infer_msgs.msg._face_recognition import FaceRecognition  # noqa: F401
