// generated from rosidl_generator_c/resource/idl.h.em
// with input from tensorrt_infer_msgs:srv/DetectLicencePlate.idl
// generated code does not contain a copyright notice

#ifndef TENSORRT_INFER_MSGS__SRV__DETECT_LICENCE_PLATE_H_
#define TENSORRT_INFER_MSGS__SRV__DETECT_LICENCE_PLATE_H_

#include "tensorrt_infer_msgs/srv/detail/detect_licence_plate__struct.h"
#include "tensorrt_infer_msgs/srv/detail/detect_licence_plate__functions.h"
#include "tensorrt_infer_msgs/srv/detail/detect_licence_plate__type_support.h"

#endif  // TENSORRT_INFER_MSGS__SRV__DETECT_LICENCE_PLATE_H_
