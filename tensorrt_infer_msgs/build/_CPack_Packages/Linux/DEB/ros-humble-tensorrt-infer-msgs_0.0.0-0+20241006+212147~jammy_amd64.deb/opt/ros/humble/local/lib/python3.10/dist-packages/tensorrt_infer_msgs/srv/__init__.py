from tensorrt_infer_msgs.srv._detect_licence_plate import DetectLicencePlate  # noqa: F401
