// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TENSORRT_INFER_MSGS__MSG__FACE_RECOGNITION_HPP_
#define TENSORRT_INFER_MSGS__MSG__FACE_RECOGNITION_HPP_

#include "tensorrt_infer_msgs/msg/detail/face_recognition__struct.hpp"
#include "tensorrt_infer_msgs/msg/detail/face_recognition__builder.hpp"
#include "tensorrt_infer_msgs/msg/detail/face_recognition__traits.hpp"

#endif  // TENSORRT_INFER_MSGS__MSG__FACE_RECOGNITION_HPP_
