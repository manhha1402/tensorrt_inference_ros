// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TENSORRT_INFER_MSGS__SRV__DETECT_LICENCE_PLATE_HPP_
#define TENSORRT_INFER_MSGS__SRV__DETECT_LICENCE_PLATE_HPP_

#include "tensorrt_infer_msgs/srv/detail/detect_licence_plate__struct.hpp"
#include "tensorrt_infer_msgs/srv/detail/detect_licence_plate__builder.hpp"
#include "tensorrt_infer_msgs/srv/detail/detect_licence_plate__traits.hpp"

#endif  // TENSORRT_INFER_MSGS__SRV__DETECT_LICENCE_PLATE_HPP_
